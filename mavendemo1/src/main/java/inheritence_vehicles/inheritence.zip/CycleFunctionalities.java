package inheritence_vehicles;

public interface CycleFunctionalities {

	public void movePedals();
	public void applyBreak();
	public void releaseBreak();
}
