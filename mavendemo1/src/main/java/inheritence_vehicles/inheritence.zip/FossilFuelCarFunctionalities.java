package inheritence_vehicles;

public interface FossilFuelCarFunctionalities {
	public void fillFuel(int fuelVolume);
	public void displayFuelLevel();
}
