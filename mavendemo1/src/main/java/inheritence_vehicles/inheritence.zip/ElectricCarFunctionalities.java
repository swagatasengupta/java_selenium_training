package inheritence_vehicles;

public interface ElectricCarFunctionalities {
	public void chargeCar();
	public void displayChargeLevel();
}
