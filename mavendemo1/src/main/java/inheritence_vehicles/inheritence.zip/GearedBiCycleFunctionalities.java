package inheritence_vehicles;

public interface GearedBiCycleFunctionalities {
	public void changeGear(int gearNum);
}
