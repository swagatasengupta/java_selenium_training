package inheritence_vehicles.subpackage1.subpackage_1_1;

import inheritence_vehicles.Vehicle;

public class Cycle2 extends Vehicle {

}
