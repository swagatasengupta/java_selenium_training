package inheritence_vehicles;

public interface CarFuntionalities {

	public void openDoor();
	public void closeDoor();
	public void startWiper();
	public void stopWiper();
	public void startEngine();
	public void stopEngine();

}
